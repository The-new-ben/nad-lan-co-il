# Portable Talking Avatar Studio

Package version: 2026-11-08.7. Read talking-agent/skill/SKILL.md and the relevant references, then talking-agent/prototype-3d/PUBLIC-PILOT.md for the current dated deployment and response evidence. Earlier sections and receipts are historical; they do not prove today's readiness.

The approved NadLan public scope is only WordPress page 5154. Other projects need their own role, brand, facts and authorization. Sample approval, a local response, public transport, and verified browser playback are separate milestones. Do not turn one into another or claim physical-phone testing from Chrome viewport emulation. This package makes no world-best, automatic-memory, publishing or spending claim.

Paths outside this archive intentionally refer to Ben's computer. Tool/key registries, credentials, model runtime, private user recordings and unrelated files are excluded. Request only the needed sanitized evidence when a linked result is unavailable. The receiving agent must actually read the files; no provider account was contacted or updated by creating them.

This builder writes only the local portable archive and its receipt. It performs no repository/worktree copy, export, commit, upload or deployment. Root owns any separately authorized export.
