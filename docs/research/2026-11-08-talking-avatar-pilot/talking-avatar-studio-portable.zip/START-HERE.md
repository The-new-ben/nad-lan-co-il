# Portable Talking Avatar Studio

Read talking-agent/skill/SKILL.md and only its relevant references. This package preserves the actual work and limitations as of8 November2026. It can be attached to Grok, Claude or another agent. No provider account or automatic memory was updated by creating it.

The included project documents and receipts are dated evidence. Paths outside this archive point to Ben's computer and are intentionally not bundled. Tool/key registries, credentials, model runtime, private user recordings and unrelated project files are excluded. Request only the sanitized source needed for a new task; never invent a missing execution result.

Current state: the NadLan small portrait/greeting and controls are live on the one approved English page. Its actual public generated question returned503 under insufficient available RAM. Complete that first pilot before creating additional characters. Other projects require their own role, brand, facts and authorization. This package creates no deployment or spending permission.
