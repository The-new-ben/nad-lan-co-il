# Talking advisor: a face that pops up and talks (every file and fact in one place)

**For Ben, in Hebrew:** כאן נמצא כל מה שנבנה עד היום לדמות המדברת: הפרצוף, תנועות הפה, הקול, הדף שהיא עולה בו באתר, הסרטונים והסקריפטים. היא חיה עכשיו באנגלית בדף אחד בלבד (למטה). השלב הבא שביקשת: פרצוף קטן ותלת־ממדי שקופץ, לא כרטיס גדול, עם תנועות שפתיים מינימליות, ונבנה ב-Blender. העבודה עוברת ל-ChatGPT Astra 6 (דרך Codex) ומתחילה מכאן.


**החלטת בן, 7.11.2026 בלילה:** היועצת נשארת חיה בדף האנגלי כמו שהיא. העבודה עליה משותפת ל-Claude ול-Astra 6 (Codex), וכל אחד מעדכן מכאן.
- **התיקייה:** `C:/Users/777/Documents/agent-tools/talking-agent/`
- **הסקריפט שמעלה, מעדכן ומוריד אותה מהאתר:** `C:/Users/777/nad-lan/nad-lan-co-il/docs/research/2026-11-07-talking-agent/deploy_live.py`
- **הדף:** https://nad-lan.co.il/en/buy-property-in-israel/

For agents (ChatGPT Astra 6 / Codex, Claude, Grok): read this whole file first. Everything below was checked on 7.11.2026, night.

## 1. What Ben wants (his words, 7.11.2026)
- A face that pops up and talks to the visitor as soon as they enter: "משהו אקטיבי, פרו-אקטיבי שמדבר איתך איך שאתה נכנס". Not a form.
- A beautiful blonde Israeli woman: "אישה יפה, מדהימה... בלונדינית, ישראלית". The bearded older man from the first try was rejected.
- The voice is Chatterbox: "מדברת עם צ'אטרבוקס".
- English only for now: "כרגע תעשה רק באנגלית".
- Lip movement very small: "תעשה תנועות שפתיים ממש מינימליות".
- **Next (the job for Astra 6):** "זה גדול מדי, זה תופס את כל הזה... משהו שצריך לקפוץ קטן, שכזה פרצוף קטן שמדבר, תלת ממדי, תשתמש בבלנדר". So: a SMALL 3D talking face that pops up, not the current big card.
- Later, maybe: connect it to AI for a real conversation ("אולי נחבר אותה גם ל-AI בעתיד"). This is preparation.
- It is an EXPERIMENT on one marginal page, not a sitewide feature. Ben said an earlier session "took it too seriously and burned my usage".

## 2. What is live right now
- **Page:** https://nad-lan.co.il/en/buy-property-in-israel/ (WordPress page id 5154, the English guide for buyers from abroad). Only this page.
- **What the visitor sees:**
  - A dark card pops up 1.2 s after load: "NadLan advisor · A computer-made character".
  - The face sits in a square, with a caption that highlights word by word, and two buttons: "Chat with our team" (opens the site's WhatsApp) and "Hear again". The ✕ closes it, and it stays closed for that visitor (`localStorage` key `nlag-closed`).
  - The voice starts on the visitor's first tap anywhere on the page, because browsers block sound before a tap. Until then a "Tap to hear her" button shows on the face.
- **How it is built:** one block appended at the end of the page content, between `<!-- nlagent:start -->` and `<!-- nlagent:end -->`. It holds scoped CSS (`.nlag*`), the markup, and a script with `window.__NLAG` (media URLs, mouth cues, text).
  - It adds no headings and no keyword text, so it does not touch SEO.
  - It never covers the green WhatsApp pill or the accessibility button. This was checked at 390, 360 and 1366 widths.
- **Media library files:**
  - `https://nad-lan.co.il/wp-content/uploads/2026/11/nlagent-face-v1.webp`, `nlagent-mouth-b-v1.webp`, `nlagent-mouth-c-v1.webp`, `nlagent-blink-v1.webp`, `nlagent-greet-en-v1.mp3`.
- **Turn on, update or remove.** Run from the repo copy, because it uses the repo's deploy helpers:
  - `python C:\Users\777\nad-lan\nad-lan-co-il\docs\research\2026-11-07-talking-agent\deploy_live.py` shows a dry plan.
  - `--go` publishes or updates. It backs up first into `page-backup/` and reads back after.
  - `--remove` takes the block off the page.
- **Press it like a visitor:** `press_live.py` (Chrome on a phone size; records video with the voice; checks for overlaps).
- **Problem Ben named:** the card is too big. It covers most of a phone screen, from the H1 down.

## 3. The kit (`kit/`, a copy of `nad-lan-co-il/docs/research/2026-11-07-talking-agent/`)
| What | Files | How it was made |
|---|---|---|
| The face (fictional, AI-made, not a real person) | `face-a.png` = `base.png` (chosen), `face-b.png` (other option), `pick.jpg` | `gen_face.py`: OpenAI `gpt-image-2.6-sunburst`, 1024×1024, key read inside the script only from `C:\Users\777\Documents\jus-tice-secrets\openai\` (never print it) |
| Mouth shapes and blink | `frame-B..G.png`, `frame-BLINK.png` (full frames), `raw-*.png`, `shapes.jpg` (contact sheet), `boxes.jpg` (mouth and eye regions) | `edit_shapes.py`: masked image edits inside the mouth or eye ellipse, composited with a feathered mask so the rest stays identical. Mouth box (450,450,630,590), eyes (420,300,660,385) in the 1024 image |
| Web patches | `demo/face.webp`, `demo/m-*.webp`, `demo/meta.json` | `make_patches.py`: crop to 512 and transparent patches |
| English voice (final) | `greet-en.wav` (float), `greet-en-16.wav` (16-bit) | `voice_local3.py`: **local Chatterbox Multilingual** on CPU in `C:\Users\777\nad-lan\voice-rig\venv` (cached weights, no network, $0), guided by `ref-female.wav`, 10 s of our own local Kokoro `af_heart` voice. Each sentence is checked by Whisper and retried. Median pitch 197 Hz; every sentence heard exactly |
| Hebrew voice (NOT good enough) | `greet-he.wav`, `take1/`, `take2/` | The local Chatterbox female voice mispronounces Hebrew even with niqqud. The good Hebrew route is the Hadmaya Chatterbox gateway (Dicta, rated 4.7/5 by Ben, `nad-lan-co-il/scripts/project-video/tts_chatterbox.py`), but it sleeps on a paid GPU. Ben did not approve that spend |
| Lip-sync timing | `greet-en.cues.json` | Rhubarb Lip Sync 1.14 (`C:\Users\777\Documents\Hadmaya-Visual-Studio\2026-10-28\work\rhubarb-proof\runtime\...\rhubarb.exe`), via `build_demo.py` |
| Minimal-lips rule | in `demo/template.html` and `deploy_live.py` | Every sound maps to the slightly-parted shape B, and the widest sounds to C, both at about 55% opacity |
| Local demo page | `demo/index.html?lang=en` (and `demo/template.html`) | `build_demo.py`; the background is a screenshot of the real /en/ page (`demo/bg.jpg`) |
| Videos | `rec/agent-demo-en.mp4` (local demo), `rec-live/agent-live-en.mp4` (the LIVE page on a phone, tap and speech) | `record_demo.py`, `press_live.py` (Playwright Chrome recording + ffmpeg adds the voice at the measured start) |

## 4. Other work to reuse (do not start from zero)
- **Earlier man advisor (HAD-680), rejected look:** `earlier-man-advisor-had680/`. The answering brain, with real-estate tools on the site's data and the Brokers Law limits, is in the plugin: `nad-lan-co-il/plugins/nadlan-config/inc/expert-advisor.php` and `assets/expert-advisor/`. It is switched off, and its OpenRouter key option was deleted from the site.
- **Court simulation avatar bake-off, 21.10.2026:** memory `C:/Users/777/.claude/projects/C--Users-777-Documents-ChatGPT-Work-courtai/memory/avatar-bakeoff-2026-10-21.md`. Proven there:
  - a real-time 3D talking head in the browser for $0, with `@myned-ai/gsplat-flame-avatar-renderer@1.4.0` (MIT) and `myned-ai/wav2arkit_cpu` (Apache-2.0, ONNX) at 27 to 30 fps on this PC;
  - OmniAvatar clips from one photo.
- **Blender 5.2** is installed: `C:\Program Files\Blender Foundation\Blender 5.2\`.
- **Meshy:** the Pro account key is in `jus-tice-secrets\meshy\` (script-only). It has NO face or lip features. Use it for bodies or props only.
- Shared registry entry: `C:\Users\777\Documents\agent-tools\TALKING-AGENT.md`. Voice rules: `VOICE-REUSE-INDEX.md`.

## 5. Rules that never change
- The character is fictional. It is labelled once, in small text, as computer-made, and never claims to be a person.
- On nad-lan it is never "מתווך": no viewings, no offers, no negotiation (Brokers Law). On a real listing it states only true, checked facts.
- It is injected by JavaScript or at the end of the content, with no headings and no keyword text. Never noindex, never a redirect.
- It never covers the WhatsApp pill or the accessibility button. It closes with one tap and stays closed.
- Never bypass the browser's sound rule.
- No paid GPU or paid service without Ben's yes and a number.
- Keys are read only inside scripts. Never print, commit or zip them.
- **Design:** not the default "Claude look" (no cream, gold or terracotta). The current palette is NadLan Instruments: ink `#0F2233` and `#12202A`, sea `#2F6F86`, mist `#D3DCE2`.
- Track the work in Linear (team Hadmaia) and on the Notion control-centre row (links below).
- **Release discipline on nad-lan:** back up before writing, read back after, run `python tools/source_audit.py <url>` before and after, press it in real Chrome on phone and desktop, and send Ben the live link.

## 6. Tracking
- Linear: HAD-682 (this hand-over), related HAD-680 and HAD-681.
- Notion: a row in "מרכז הבקרה של הפרויקטים".

## 7. Astra / Codex local prototype, 7 November 2026

**עדכון לבן:** נבנה ונבדק אב טיפוס מקומי של ראש קטן מאותה אישה, עם קובץ Blender ניתן לעריכה. נוספו קלט קולי ותשובה מדוברת באנגלית. הגרסה החיה לא שונתה. יש סרטוני מחשב ומידות טלפון, וההחלפה באתר עדיין מחייבת את אישורך.

- Local project: `prototype-3d/`. Start with `PROOF-OF-WORK.md`, `VISUAL-ROUNDS.md`, `RUNTIME.md` and `BACKEND.md` there. These distinguish actual successful work, failed attempts and research-only candidates.
- Preview: `http://127.0.0.1:8769/`, served by `python server.py` from `prototype-3d/`. The server is loopback-only. It is not a public conversation service.
- Editable model: `prototype-3d/nadlan-advisor-v2.blend`; browser model: `prototype-3d/assets/nadlan-advisor-v2.glb` (953,224 bytes).
- Review videos: `prototype-3d/evidence/videos/nadlan-small-avatar-phone-final.mp4` and `nadlan-small-avatar-desktop-final.mp4`. They show the actual local page, original Chatterbox greeting, and verified one-click close. Phone means Chrome viewport emulation, as Ben approved, not a physical handset.
- The small head uses inferred, photo-textured frontal geometry with subtle movement. It is not a complete 360-degree reconstruction. The exact existing fictional face and greeting were retained.
- Actual Claude Design, Gemini and Antigravity reviews and their receipts are saved locally. Blender was used to build and render the model. DaVinci startup/API connection was attempted but did not complete an edit; no Resolve rendering claim is made. FFmpeg encoded the actual Chrome captures.
- The original offline conversation pipeline is Whisper small, Qwen3-1.7B and the existing Chatterbox Multilingual with `ref-female.wav`. A real controlled spoken question produced a checked 13.36-second reply, but took 236.1 seconds in total. This is too slow for a responsive production conversation. A separately isolated official ONNX candidate is being tested; do not confuse candidate results with the approved default voice.
- Public talk-back hosting is unresolved: the website cannot access Ben's loopback server. Do not expose the computer, buy hosting or imply deployment readiness without a concrete approved hosting decision.
- No paid service or paid GPU was started. No keys were printed. No production deployment command was run.
- Tracking remains [HAD-682](https://linear.app/hadmaia/issue/HAD-682) and the existing [Notion row](https://app.notion.com/p/411ab55be7a181c98f9adcfe78140f7c).

Final local checks: the complete Chrome MediaRecorder path passed 12 checks with a labelled fake microphone. The repeated verified reply was audible 35.1 seconds after recording began. The separate ONNX candidate passed same-text word checks and worker cancellation; measured voice generation was 47.7 seconds in the isolated benchmark and 59.7 seconds in the integrated cold worker, with a short warm reply in 7.2 seconds. These are not total live-conversation timings or human approval of the changed voice model. The original voice remains the default.

An additional uncut browser recording is `prototype-3d/evidence/videos/nadlan-small-avatar-conversation-final.mp4`. Its question is typed, Qwen genuinely runs for 21.2 seconds, and the verified previous Chatterbox recording is reused. The wait is retained. See `evidence/conversation-video-qa.json` for the exact limits.

Next: Ben reviews the appearance and voice samples. Keep the goal and HAD-682 open until the response latency and eventual public-hosting decision are resolved. Do not change the single live English page before explicit approval.

Further local work: the original and candidate widgets now prevent two verified delayed-microphone-send races. The optional sentence-streaming client passed ordered playback and failure recovery checks. Separate warm inference improvements are measured, but the combined candidate still needs a real first-audible-sentence benchmark when enough memory is available. It is not the default. Details: `prototype-3d/research/latency-integration-round.md`. No new production change, voice approval or responsive-conversation claim is implied.

## 8. Authorization update, 8 November 2026

Ben explicitly asked to put the pilot on the existing English buying page and email him working links. This supersedes the earlier wait-for-deployment-approval instruction above. Scope remains only page 5154 and its existing avatar block. No paid service is authorized. The current publication and exact readback are recorded in `prototype-3d/evidence/public-deployment/latest.json`.

The free public conversation route is a same-origin WordPress relay with an outbound worker on this computer. It opens no public listener here and uses the existing local Chatterbox. Code and contract are in `prototype-3d/public-relay/`. Actual model latency remains a limitation. A recorded public request was rejected for insufficient available memory. Memory recovery work continues; obtain a fresh readiness result instead of treating a historical free-RAM reading as current. Successful controlled relay tests do not establish a successful real public reply.

The initial publication was `v-1701190a83c6`, followed by recovery release `v-2d37e9a1a8ad`. Current release `v-6dff055c6784` contains 14 files totaling 4,914,004 bytes and replaces only the existing avatar block on page 5154. Exact readback and unchanged content outside the block were verified. Explicit `revealDelay:0` reveals the portrait on entry, while sound waits for a trusted gesture. The approved face, original English Chatterbox voice, ink/sea palette and IBM Plex Sans are unchanged. Original review-video URLs under `v-1701190a83c6` remain valid; the release does not regenerate those clips.

Persistent close now leaves a small **Talk** control. Its trusted click reopens the guide and starts the original greeting. The explicit [recovery link](https://nad-lan.co.il/en/buy-property-in-israel/#talk) reveals it silently, removes only the guide's saved dismissal and consumes the fragment. Closing again stays closed after ordinary reload. The recovery passed 40 focused local checks and 28 anonymous live checks, with no conversation inference in those suites. Receipts are `prototype-3d/evidence/visibility-recovery/v-2d37e9a1a8ad/receipt.json` and `prototype-3d/evidence/visibility-recovery/v-2d37e9a1a8ad-live/receipt.json`; native owner-profile phone-size evidence is `prototype-3d/evidence/visibility-recovery/live-native-phone.png`.

The current release passed 47 controlled local polling checks, seven local immediate-reveal checks and 16 fresh anonymous live visibility/greeting/closure checks at 390 and 1366 pixels. Polling retries apply only to recognized GET `429 busy`, never question resubmission; close aborts waits. Those checks used prerecorded speech or no speech inference. See `prototype-3d/evidence/latency/poll-busy-retry/v-6dff055c6784/receipt.json`, `prototype-3d/evidence/visibility-recovery/v-6dff055c6784/immediate-config/receipt.json` and `prototype-3d/evidence/visibility-recovery/v-6dff055c6784-live/receipt.json`. The earlier 40/28 recovery checks remain dated coverage, not reruns on this release.

The earlier public question returned 503. A later genuine public request using a controlled Windows-synthesized WAV completed Whisper in 10.672 s and Qwen in 12.938 s, then was cancelled for critical memory during original MTL voice work: 55.219 s local, 58.172 s HTTP elapsed. Peak original-voice process memory reached 6.060 GiB resident and 8.090 GiB commit before cancellation; sampled free physical RAM reached 0.0445 GiB. These are historical measurements of an interrupted run, not current availability, a complete synthesis peak or a successful public spoken reply. The worker now requires both 7.1 GiB available physical RAM and 9.1 GiB available commit capacity before original port 8769 admission. Candidate port 8770 retains its separate 3 GiB physical check. The new worker gate/retry suite passed 28 controlled checks. Loader optimization remains pending; the original voice is unchanged.

The first actual user microphone upload had a long WebM timestamp gap: the 20.1 s timeline cutoff left 0.119 s decoded audio. Do not blame this simply on a short recording. A later 4.02 s decoded upload reached Whisper, Qwen and TTS; its cancellation cause is not established by old logs. See sanitized `prototype-3d/evidence/public-relay/recent-job-diagnostics.json`, the controlled public test in `evidence/public-relay/real-reply-recovery/receipt.json`, and `evidence/memory-recovery/public-original-audio-summary.json` under the prototype.

A completed public spoken reply is still outstanding. Ben was emailed the live page and the two review-video links with the voice limitation stated. Historical receipts and failures are preserved. Start at `prototype-3d/PUBLIC-PILOT.md` for current operation and scoped rollback, not the historical large-card deployment command above.

Ben's next instruction is to preserve all learning for Codex, Claude and Grok and reuse it for Hadmaya/Justice. Canonical shared skill: `skill/SKILL.md`, with local Codex/Claude discovery wrappers. Grok receives portable readable files, not an assumed automatic memory update. Additional characters wait until the first pilot is complete. Future direction: natural, attractive, neatly groomed adult fictional Israeli-context women and men, including blonde and tanned-skin options, with no exaggerated or messy styling.
