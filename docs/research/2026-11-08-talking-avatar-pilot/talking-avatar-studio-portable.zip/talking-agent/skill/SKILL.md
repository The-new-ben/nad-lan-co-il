---
name: talking-avatar-studio
description: Build, resume, adapt or review a browser talking advisor with a face, local speech, lip timing and interruption controls. Reuse the existing NadLan, Hadmaya and Justice work, compare candidates with evidence, and prepare a scoped release or future character library. Use for talking-avatar projects, not ordinary narration or unrelated image generation.
---

# Talking Avatar Studio

Provider-neutral working knowledge for Codex, Claude, Grok and other agents. The canonical copy is this directory. Read only the references needed for the current task. File availability does not prove that another agent loaded it, that a service is running, or that a model is approved.

## Start from the existing work

1. Read the current user request and preserve its authorized scope. For the existing NadLan project, read the whole [project README](../README.md) and [current public handoff](../prototype-3d/PUBLIC-PILOT.md), then the relevant current receipts in the [evidence map](references/evidence-map.md). Earlier prose can be superseded by later authorization and actual readback. A deployment receipt proves its recorded write, not today's service health.
2. Before installing or replacing speech code, read [VOICE-REUSE-INDEX](../../VOICE-REUSE-INDEX.md), its [checked-path manifest](../../voice-reuse-index.json), and the relevant current source. Before saying a tool or key is unavailable, inspect [TOOLS-AND-KEYS](../../TOOLS-AND-KEYS.md) inside the trusted local environment. Never copy credentials into this skill, prompts or attachments.
3. Record what is being changed: project, page, language, character, voice model/reference, runtime, and evidence needed. Reuse approved files before regenerating. Keep local candidates separate until the requested comparison and approval are complete. Do not silently change the approved voice, face, default engine or public scope.
4. Continue the existing issue and Notion row. NadLan uses HAD-682 and its existing row, linked in the evidence map. A new project needs its own tracking and project context rather than inheriting NadLan permissions.

## Choose the relevant path

| Work | Read |
|---|---|
| Browser, voice, latency, cancellation, relay or release | [Operational lessons](references/operations.md) |
| What actually ran, exact timings, failures and proof locations | [Evidence map](references/evidence-map.md) |
| Reuse for Hadmaya, Justice or another domain/language | [Domain adaptation](references/domain-adaptation.md) |
| Future male/female characters and comparable identity review | [Character library brief](references/domain-adaptation.md#future-character-library-brief) |
| Codex/Claude discovery, Grok attachment, synchronization | [Portable use](references/operations.md#portable-use-and-one-source-of-truth) |

## Preserve these decisions

- The existing fictional NadLan woman, reference WAV and recorded greeting are approved source assets. The small model is photo-textured frontal geometry, usable within about three degrees of frontal. It is not a complete volumetric head, full 360 reconstruction or full facial rig.
- Speech must follow a trusted browser interaction. Microphone permission comes from an intentional microphone action. Ordinary taps, reveal/loading callbacks and cancelled asynchronous work must not start a greeting over listening or another reply. Close persists and stops owned audio, recording, analysis and backend work.
- Keep mouth movement subtle. The present learned visemes project to one `mouthOpen` shape; blink is independent. Drive animation from the currently playing audio clock. More mouth activity is not evidence of better synchronization.
- The original local Chatterbox Multilingual remains distinct from the optional Turbo ONNX q4 candidate, even with the same reference WAV. Word checks and voice embeddings support comparison; neither substitutes for listening approval or proves identical voice quality.
- Benchmark one controlled change at a time, retain failed attempts and identify cached audio, fake-device input and controlled backends explicitly. Full pipeline time, time to first audible sentence, warm inference, import/model load, and complete-file time are different measurements. Do not add independent benchmarks and present the sum as a measured conversation.
- No paid service, paid GPU wake-up or existing-credit consumption is authorized merely because a key, plan or credit balance exists. Apply explicit current authorization, including its amount and scope. Complete reversible preparation before asking for any missing decision. Do not ask again for permission already granted.
- Ben authorized the public NadLan pilot only on existing WordPress page 5154 and an email of working links. This historical permission does not authorize another page, project, recipient, sitewide rollout or future service spend. Recheck current instructions before external writes.
- Preserve the host page and the owner's measurement settings. Do not add analytics masking, exclusions or recording restrictions. Keep existing WhatsApp and accessibility controls reachable, one-tap close, disclosure and reduced-motion behavior.
- Visual work follows Ben's Claude Design workflow and a project-specific brief. State the actual palette, fonts and why the result avoids the default cream/gold treatment. Do not claim an app was used unless a receipt supports that use. Do not inherit the NadLan woman as a Justice judge.
- Complete the initial avatar pilot before generating additional characters. The library section is a future brief, not a generation instruction or a claim that those assets exist.

## Finish with reviewable evidence

Report the observed result, tested scope, material remaining limits and exact artifact/receipt paths. Distinguish local preparation, published assets, functioning public transport and a genuinely generated public spoken reply. Update the existing tracking record when authorized. Keep the canonical skill and references current when a new result supersedes a dated fact; validate the package and refresh its manifest as described in portable use. Never turn a research candidate, controlled fixture or failed app startup into a successful product claim.
