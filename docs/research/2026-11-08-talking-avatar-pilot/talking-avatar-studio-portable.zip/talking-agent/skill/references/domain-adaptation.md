# Adapting the workflow to another project

Reuse engineering and evidence. Re-establish domain identity, knowledge, language, role and authorization. The prior NadLan deployment or a reusable key is not permission to deploy, message people, spend credits or use a person's likeness in another product.

## Compact project brief

Before implementation, recover these from current project sources and the user. Ask only for genuinely missing decisions that block dependent work; continue useful reversible preparation.

| Field | What to establish |
|---|---|
| Product and surface | Exact project/repository, page or application, audience, journey and approved intervention |
| Character | Fictional adult identity, role, source/hash, approved face and voice; written consent if a real person is used |
| Role boundaries | What it can answer or do, what requires a human, how it describes itself without false credentials |
| Knowledge | Current authoritative content/data, source dates, unknown-answer behavior and permitted tools; no fabricated listings, laws, prices or availability |
| Language | Actual user-facing language, dialect/accent, right-to-left behavior, captions, name/number pronunciation and test corpus |
| Brand | Exact palette and typefaces from that project's actual design sources, geometry/control treatment, and one sentence explaining the nondefault visual direction |
| Runtime | Device/host constraints, local or approved remote inference, availability and expected response time |
| Authorization | Current page/deployment scope, costs/credits and recipients; previous explicit approval still applies within that scope |
| Acceptance | Fixed comparison audio/text, listening/identity review, browser interactions, content accuracy, failure behavior and a scoped release receipt |

Route visual creation/review through Claude Design under the owner's workflow when available and authorized. A written brand brief or attempted app launch is not a completed design review. If that route is unavailable, report the actual limitation and prepare source-grounded work without inventing a review. Do not add a new cross-project approval gate where the user has already authorized the action.

## Existing NadLan identity

Use NadLan Instruments ink `#0F2233`/`#12202A`, sea `#2F6F86`, mist `#D3DCE2`, white, and IBM Plex Sans for its current UI. The small transparent head and precise controls follow the site's instrument/map character, avoiding cream, gold, terracotta and generic card styling. Preserve skin/hair identity independently from UI colors.

The existing character is a fictional computer-made guide, not a broker. The project rule prohibits arranging viewings, sending offers or negotiating. Use checked page/listing facts; the present local brain uses a saved guide, not live property inventory. This is an existing product boundary, not a new legal opinion. Verify current authoritative law separately if a new feature depends on it.

## Hadmaya

Recover the specific Hadmaya product and its approved design/role from that project's files. The visual studio, court simulator and a sales/explanation product need not share a persona. Reuse the voice index, speech preparation and queue/cancellation lessons. Preserve current owners, pinned models and existing assets. Do not assume the NadLan palette, woman, English reference or narrow real-estate knowledge belongs here.

## Justice and court-related experiences

Read the existing court avatar bank and simulation context identified by the [shared talking-agent index](../../../TALKING-AGENT.md) before making new assets. Distinguish a product guide, fictional simulated participant and real licensed professional. A fictional judge in a clearly identified simulation is not a claim of actual judicial authority. Do not automatically dress the NadLan woman as a judge or transfer her persona/voice approval. Re-establish legal content sources and product role boundaries; no professional credential or outcome promise may be invented.

Existing Hebrew Chatterbox/Dicta service code and historical listening evidence are reusable knowledge. That gateway may wake a paid GPU. Do not invoke it as a free health check. Current local English results do not prove Hebrew pronunciation or service availability. Use the existing Hebrew corpus and source preparation before proposing a new stack, then test the intended names, dates, numerals and legal vocabulary with the requested voice.

## Cross-project design and release criteria

Ben rejects default cream/beige/parchment, brown/tan/terracotta/rust/brass/gold/mustard accents, sepia, serif-on-cream broadsheets, near-black with a token acid-green/vermilion accent, generic purple-blue gradient heroes, default Inter/Space Grotesk, emoji section icons and repetitive soft-shadow cards. Choose actual project typography and colors rather than automatically substituting the NadLan palette everywhere.

Keep the computer-made disclosure, deliberate microphone action, browser sound policy, accessible close and nonoverlap rules. Re-test surrounding controls in the new host instead of assuming NadLan selectors apply. Preserve the owner's measurement configuration. Require evidence appropriate to the task, not a full benchmark rerun for every small reversible change. A new language, face, voice model, public host or chunking contract needs its own relevant checks and must retain the existing approved version for comparison.

## Future character library brief

Owner direction, 8 November 2026: **finish the initial avatar fully first**. Additional characters are a subsequent task. This reference creates no images, meshes, voices or generation jobs, and does not approve a spend or deployment. A published page alone is not a reason to skip the initial pilot's outstanding functionality and review.

### Creative direction

Build a balanced library of adult fictional men and women for Israeli product contexts. They should look attractive, natural, composed and neatly groomed, with subtle realistic expression. Include blonde women among a varied set of looks and allow tanned-skin options. Avoid exaggerated features, caricature, sexualized presentation and messy or exaggerated beards. Groomed facial hair can be considered where it fits the approved brief.

Israeli context is a creative/persona setting supplied by the owner. Do not infer or certify nationality, ethnicity or religion from an image. Do not narrow the library to a stereotyped appearance. Select a character for the actual product and role, not automatically by gender. Keep Hadmaya/Justice casting distinct from the approved NadLan advisor unless reuse is explicitly chosen.

Each visual prompt must include the target project's confirmed UI palette, typefaces and a sentence explaining its subject-specific design direction. These describe the presentation and review board, not a command to recolor skin/hair. For NadLan only: ink `#0F2233`, sea `#2F6F86`, mist `#D3DCE2`, white, IBM Plex Sans. Do not substitute cream/gold defaults. For another project, first retrieve its own brand sources.

### Preparation after the initial pilot

Reuse the existing portrait-bank specification and approved assets before generating. A neutral front portrait with closed relaxed lips and clearly visible eyes is a useful baseline, but inspect the actual rigging pipeline before fixing new dimensions/crops. Preserve the full raw source, its provenance and any rights/consent. Do not use a real person's face or voice without the owner's required written consent.

Assign a stable character ID independent of filenames. Keep a compact record with:

- project and intended role; adult fictional status or documented consent;
- source image/hash, creation source/date and actual usage rights;
- creative brief and exact model/settings/cost, if generated;
- approved neutral portrait, editable mesh, exported GLB, texture/licence files and hashes;
- supported viewing range, shape keys, blink method, geometry/transfer budget;
- voice engine/revision, exact reference hash and approval status;
- language/pronunciation corpus, fixed WAVs and word/listening checks;
- identity, minimal-lip, browser-performance and interaction evidence;
- status such as proposed, comparison, approved for named project, or rejected, with reason.

Do not create empty asset entries that imply characters exist. Never attach API keys, signed administrative links, private credentials or private raw user recordings to a library package. Share only the files necessary for the review.

### Fair comparison

Use the same neutral camera/crop, small display size, lighting, source image and voice WAV. Compare identity at the intended frontal range before diagnostic side views. An inferred plausible side is not reconstructed ground truth. Optional face embeddings and landmark errors support, but do not replace, the owner's identity judgment.

For lips, compare normalized aperture, neutral return, visible seams and timing on pauses and manually labelled p/b/m closures. Automatic Rhubarb or learned labels are not human ground truth. Keep the gain comparable; exaggerated jaw motion must not earn a better score merely by moving more.

Record GLB/texture transfer size, first visible frame, memory and frame-time median/p95 in the same browser/device conditions. Preserve actual audio timing and uncut waits in review clips. Viewport emulation does not prove physical-phone performance. A static beauty image or mesh vendor benchmark cannot establish a better talking avatar.

A candidate passes only the scope actually checked. It remains separate until the owner approves the chosen look/voice and the relevant interaction/content checks pass. No automatic replacement of an existing project's approved character follows from adding a library entry.
