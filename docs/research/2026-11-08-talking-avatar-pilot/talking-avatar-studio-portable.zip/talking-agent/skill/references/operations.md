# Operational lessons

Use current source and receipts, not old commands copied without checking. This reference captures why the existing implementation behaves as it does.

## Reuse and local runtime

The project is `C:/Users/777/Documents/agent-tools/talking-agent/prototype-3d/`. Read [RUNTIME](../../prototype-3d/RUNTIME.md), [BACKEND](../../prototype-3d/BACKEND.md) and [STREAMING](../../prototype-3d/STREAMING.md) for the current contracts. The shared voice index links earlier Dicta, style forwarding, VibeVoice text preparation, queues, 100-sample research and 48 intent takes. Do not rediscover or overwrite those fixes.

The measured laptop is Ryzen 7 7730U, 8 physical/16 logical cores, about 13.85 GB installed RAM, integrated Radeon, no NVIDIA GPU. Heavy agents share this memory. Coordinate a single inference slot, inspect available memory, and release owned processes after a test. More threads were not automatically faster. Do not close owner applications or lower the existing memory reserve to force a benchmark.

The original voice environment is `C:/Users/777/nad-lan/voice-rig/venv/`. Reuse it without rebuilding. Candidate dependencies were extracted in task-specific `.runtime` folders, with official source revisions, licences and hashes. Do not make a candidate library path global. Inference was offline; provider documentation or a model's presence does not prove runnable hardware support.

Original review configuration: `python server.py` from the project, loopback port 8769. Optional combined candidate: `python server.py --port 8770 --voice-engine onnx-q4 --streaming --prewarm --persistent-brain --stt-engine faster-small-en`. This is a different voice model and explicit comparison mode, not a recommended silent default switch. Health checks inspect availability without loading a model. Inspect current flags/source before launch and avoid starting a duplicate server.

## Speech and latency

Measure upload/decode, STT, answer generation, model/import startup, TTS, lip analysis and actual browser playback separately. Save the exact question, answer, audio, settings, engine/revision, reference hash, timestamps and cache flags. Use the same text and reference for a voice comparison. A warm short question is not comparable with a cold long reply.

The original fresh pipeline succeeded but took 236.093 seconds. Optional ONNX q4 and int8 English recognition improved separate stages. The combined fresh-inference first-audible result remains unmeasured in the dated snapshot because the 3 GiB reserve rejected the test. Resource rejection is a successful guard, not successful inference. A shorter Qwen prompt was rejected after losing a substantive caveat; speed does not override answer quality.

Later original-voice memory evidence changes public admission, not the selected model. A genuine controlled-WAV public attempt on 8 November completed Whisper and Qwen but was cancelled during MTL voice work after critical memory pressure. Original MTL reached 6.060 GiB peak resident memory and 8.090 GiB peak process commit before cancellation; sampled free physical memory reached 0.0445 GiB. The public worker now requires both at least 7.1 GiB available physical RAM and 9.1 GiB remaining commit capacity before admitting work to original port 8769. The optional 8770 candidate retains its separate 3 GiB physical guard. These thresholds reflect an interrupted peak plus reserve, not a guarantee of successful completion. Commit capacity is a Windows memory limit, not free disk space. Loader optimization remains pending; do not claim it has reduced the observed peak.

Whisper content checks catch hallucinated, repeated or omitted words. Retain raw transcripts and normalization rules, including numeral formatting. Check names, prices, dates and addresses independently. Listen to candidate speech for identity, pronunciation and naturalness; ASR and uncalibrated voice-similarity scores are supporting evidence only. An English-only model or clean Windows speech fixture does not establish Hebrew, noisy microphone or diverse-accent quality.

True sentence streaming publishes a genuinely generated sentence before generating the next. `CPUVoiceEngine.iter_generate` yields individually watermarked audio; the wrapper adds the nonfinal 220 ms gap and waits for server publication acknowledgment before advancing. Complete-file slicing is not model streaming. Retain generation-start, generation-end and publication timestamps. Partial failure must invalidate old chunks and prohibit replay as a complete answer.

Voice cache keys must include answer text, engine/settings and exact reference hash. Keep original/candidate caches separate and report hits. Resident voice and brain workers compete for RAM; evicting one can remove the next turn's warm advantage. Cancel the entire owned Windows process tree, including launcher children, and deny late results/audio. Never kill unrelated processes.

## Browser lifecycle invariants

The model reveal may change only the initializing state. First interaction before reveal must still work. A microphone start marks the conversation as started so a delayed first greeting cannot interrupt it. Pause/resume uses the same audio clock; hidden pages stop animation, and close disposes rendering resources.

Persistent close needs an intentional recovery path. The old large card and small portrait shared `nlag-closed`, so an earlier dismissal could make a correctly deployed avatar invisible. The current NadLan release shows a 72 by 44 pixel Talk button only while closed. A trusted click reopens once and plays the original greeting. `#talk` clears only the configured guide-dismissal key and reveals silently; consume that fragment once so a subsequent close survives reload. Never clear unrelated storage, rename the key to evade a visitor's close, or reopen automatically on an ordinary visit.

Reopening must recreate the disposed renderer and attach listeners once. Guard asynchronous GLB completion and failure with a model-generation identifier: a request from before close must not populate, dispose or overwrite the reopened guide. Test delayed success/failure, repeated close/reopen, exactly one guide and playback, keyboard activation and the actual surrounding controls. The recovery retained the approved original voice and NadLan ink/sea palette with IBM Plex Sans; it did not generate a new identity.

Each recorder owns its chunks and request generation. Native `MediaRecorder.stop()` makes the recorder inactive before its later `stop` callback. Therefore cancel must invalidate the send generation even when the recorder already appears inactive. Typed submission must invalidate and stop recording before it starts its request. Late permission results close their own tracks if cancelled, replaced, hidden or closed. These two send races were reproduced in actual native MediaRecorder and fixed, not merely proposed.

A short decoded WAV does not prove the visitor spoke briefly. One real WebM had a 234.095 s packet timestamp gap; the existing 20.1 s timeline cutoff retained 0.119 s, which failed the 0.25 s transcription minimum. Inspect container packet timing and decoded samples before describing microphone failure. A later upload completed STT/Qwen and entered TTS, but old collapsed logs did not establish its cancellation cause. Do not label it a polling 429 without request evidence or confuse a controlled synthesized WAV with a physical-microphone test.

Create a visitor-bound request token before upload. Cancel by token when a job ID is not yet known; if the ID arrives late, cancel that owned job too. Old responses, playback promises and analysis completions cannot overwrite a newer request's state. Session refresh is bounded to one retry and specific authentication/session-expiry responses; refreshing must still respect close/cancel. Do not indiscriminately retry a possibly committed speech submission.

The relay's short queue lock can return `429` with code `busy` on an accepted job's GET poll. Retain the last job state and retry only that GET, at most three extra attempts with 1/2/4 s backoff; respect a larger numeric or HTTP-date `Retry-After` within the 600 s response deadline. Reset this contention counter on a successful poll. Other 429 codes and 401/403 fail without retry. Close must abort both normal polling waits and backoff, cancel the owned token/job and suppress late audio. This change must never resubmit the question POST. Worker private-call contention has its own bounded retry logic.

Use ordered immutable chunk indices, reject changed duplicates, and detect a missing final sequence. Test cancel during preparation/playback, later-sentence failure, replay of the full answer, and a fresh question after failure. Prefetching may overlap playback; playback and visemes must use the same current chunk and its audio time.

The existing portrait's single shape cannot express independent lip rounding, spreading, tongue or teeth. Preserve small gain and neutral return. `dynamic-lips.js` owns analysis, not playback. Its worker can be aborted; failure may use supplied cues. Do not relabel amplitude windows as phoneme recognition. Check the actual small portrait during speech, not just a large static render.

## Public transport and release

Read [relay contract](../../prototype-3d/public-relay/CONTRACT.md), [worker](../../prototype-3d/public-relay/WORKER.md) and [deployment](../../prototype-3d/public-relay/DEPLOYMENT.md). A visitor's localhost cannot reach Ben's computer. The approved route uses same-origin WordPress and an outbound local worker; it opens no public listener or tunnel on this computer. No paid fallback is implicit.

Preserve visitor-owned cookie/CSRF sessions and independent local history. Worker credentials stay in memory, use the fixed HTTPS origin and refuse credential-bearing redirects. Public jobs, input, outputs and updates must remain owner/lease-bound. Renew only a valid lease; cancellation, expiry, lost lease or uncertain transport cancels the owned local request. Check ownership again when accepting output to close the check-to-publish race. Fetch only bounded allowlisted local response paths, not arbitrary URLs.

Raw microphone recordings are private transient input, not public media-library uploads or status URLs. Public audio routes expose only bounded authorized generated output. Local debug recordings under `.runtime/jobs/` have their own retention, separate from WordPress's transient expiry. Document that operational limitation honestly; it is not evidence that raw input is publicly accessible. Do not change unrelated analytics or the visitor's choices.

For a scoped page update, retain a backup and verify the exact page outside the existing `nlagent` marker block is unchanged. Stage only reviewed public assets, never Python, private runtime, source recordings or credentials. Preserve host headings and content. Check hashes/readback, actual phone-size and desktop controls, trusted interaction, close persistence, health and failure messaging. Remove temporary authenticated upload/deploy helpers and verify cleanup before declaring success. Expected-state prewrite checks are best effort, not atomic database transactions; preserve and report conflicting edits.

A page/assets deployment, relay deployment, worker availability and real public spoken reply are separate milestones. A WordPress transport test with silent or prerecorded audio does not prove Whisper/Qwen/Chatterbox inference. If insufficient RAM prevents a new turn, show the actual unavailability and preserve the recorded greeting. Publishing an asset package does not finish the pilot by itself.

Current release `v-6dff055c6784` published 14 files totaling 4,914,004 bytes on page 5154 only. Page configuration sets `revealDelay:0`; entry reveal remains silent until a trusted interaction and never overrides saved close. Current coverage is 47 local polling checks, seven immediate-reveal checks, 16 fresh live visibility/greeting checks and 28 controlled worker checks. The preceding `v-2d37e9a1a8ad` retains its 40 local and 28 live recovery receipts; see the [evidence map](evidence-map.md). Visibility tests submitted no conversation request. The later genuine public controlled-WAV request was cancelled for critical memory, so no completed public spoken reply is established. Check current readiness rather than reusing historical RAM values. Original versioned review-video links remain valid and must not be mistaken for new live-response recordings.

## Portable use and one source of truth

Canonical folder: `C:/Users/777/Documents/agent-tools/talking-agent/skill/`.

The installed local entry points are:

- `C:/Users/777/.codex/skills/talking-avatar-studio/SKILL.md`
- `C:/Users/777/.claude/skills/talking-avatar-studio/SKILL.md`

These are small pointers, not independent copies of operational knowledge. They instruct the agent to read the canonical file and the relevant references. Codex has normal `agents/openai.yaml` discovery metadata. Claude uses its existing local skills directory convention. File installation does not establish that an already running session has refreshed discovery or read the skill. Invoke it by name/path in that session when needed.

For Grok or another agent without access to this filesystem, attach `SKILL.md` and the relevant reference Markdown files from this directory, preserving filenames. The core workflow and limits remain usable without local tooling. Attach selected sanitized project receipts/source excerpts only when the task needs them. Never attach the tool/key registry, secret directories, full private runtime, arbitrary logs or user recordings by default. If relative source paths are unavailable, treat their results as the dated cited snapshot and ask for the needed sanitized evidence before claiming a fresh execution or deployment.

This package does not install a Grok connector, automatic memory, account update or message delivery. The portable files are instructions the receiving agent must actually read. No Claude/Grok conversation was contacted as part of installation.

### Maintenance

Edit canonical instructions/references in this folder. Keep wrapper routing narrow and provider-neutral. Do not copy another provider's startup/model gates, global memory policy or unrelated tool configuration into this skill. Preserve the user's active authorization; a historical permission statement cannot replace the current task.

`manifest.json` records the canonical package version, files/hashes, entrypoint targets and observed source references. It contains paths and hashes only, no credentials. The source references are snapshots of checked files; they are not copied raw facts frozen forever. Hash changes are a reason to inspect the relevant delta, not to discard newer valid work.

After a change:

1. Run the existing `C:/Users/777/.codex/skills/.system/skill-creator/scripts/quick_validate.py` on the canonical folder and both entrypoint folders using an available Python with PyYAML.
2. Resolve every local Markdown link from its containing file and check it exists. Check wrapper targets and `agents/openai.yaml`. Inspect changed external source claims when they affect the task; a static link check is not live URL verification.
3. Refresh SHA256 entries in `manifest.json` for changed package files and wrappers. Keep validation results in `validation.json`, outside the hashed package file list, so refreshing the receipt does not create a self-referential hash.
4. Ask an independent agent to use only the installed entrypoint and relevant files on representative tasks. Test reuse for another domain and an interrupted/cost-sensitive workflow. Have it report the actions it would take and source paths, rather than simply repeating the skill. Record limitations: loading instructions in a test is not proof of automatic discovery in every live app.

Only the canonical skill directories are owned by this package. Registry/README/tracking changes remain coordinated with the project owner. This avoids competing edits during an active release.
